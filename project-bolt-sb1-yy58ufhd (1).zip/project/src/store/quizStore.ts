import { create } from 'zustand';
import { QuizState } from '../types';
import { 
  fetchQuizzes as apiFetchQuizzes,
  fetchQuiz as apiFetchQuiz,
  fetchQuestions as apiFetchQuestions,
  createQuiz as apiCreateQuiz,
  updateQuiz as apiUpdateQuiz,
  deleteQuiz as apiDeleteQuiz,
  createQuestion as apiCreateQuestion,
  updateQuestion as apiUpdateQuestion,
  deleteQuestion as apiDeleteQuestion
} from '../services/quizService';

export const useQuizStore = create<QuizState>((set, get) => ({
  quizzes: [],
  currentQuiz: null,
  questions: [],
  isLoading: false,
  error: null,
  
  fetchQuizzes: async () => {
    set({ isLoading: true, error: null });
    try {
      const quizzes = await apiFetchQuizzes();
      set({ quizzes, isLoading: false });
    } catch (error) {
      set({ 
        error: error instanceof Error ? error.message : 'Failed to fetch quizzes', 
        isLoading: false 
      });
    }
  },
  
  fetchQuiz: async (id) => {
    set({ isLoading: true, error: null });
    try {
      const quiz = await apiFetchQuiz(id);
      set({ currentQuiz: quiz, isLoading: false });
    } catch (error) {
      set({ 
        error: error instanceof Error ? error.message : 'Failed to fetch quiz', 
        isLoading: false 
      });
    }
  },
  
  fetchQuestions: async (quizId) => {
    set({ isLoading: true, error: null });
    try {
      const questions = await apiFetchQuestions(quizId);
      set({ questions, isLoading: false });
    } catch (error) {
      set({ 
        error: error instanceof Error ? error.message : 'Failed to fetch questions', 
        isLoading: false 
      });
    }
  },
  
  createQuiz: async (quiz) => {
    set({ isLoading: true, error: null });
    try {
      const newQuiz = await apiCreateQuiz(quiz);
      set(state => ({ 
        quizzes: [...state.quizzes, newQuiz],
        currentQuiz: newQuiz,
        isLoading: false 
      }));
    } catch (error) {
      set({ 
        error: error instanceof Error ? error.message : 'Failed to create quiz', 
        isLoading: false 
      });
    }
  },
  
  updateQuiz: async (id, quiz) => {
    set({ isLoading: true, error: null });
    try {
      const updatedQuiz = await apiUpdateQuiz(id, quiz);
      set(state => ({
        quizzes: state.quizzes.map(q => q.id === id ? updatedQuiz : q),
        currentQuiz: state.currentQuiz?.id === id ? updatedQuiz : state.currentQuiz,
        isLoading: false
      }));
    } catch (error) {
      set({ 
        error: error instanceof Error ? error.message : 'Failed to update quiz', 
        isLoading: false 
      });
    }
  },
  
  deleteQuiz: async (id) => {
    set({ isLoading: true, error: null });
    try {
      await apiDeleteQuiz(id);
      set(state => ({
        quizzes: state.quizzes.filter(q => q.id !== id),
        currentQuiz: state.currentQuiz?.id === id ? null : state.currentQuiz,
        isLoading: false
      }));
    } catch (error) {
      set({ 
        error: error instanceof Error ? error.message : 'Failed to delete quiz', 
        isLoading: false 
      });
    }
  },
  
  createQuestion: async (question) => {
    set({ isLoading: true, error: null });
    try {
      const newQuestion = await apiCreateQuestion(question);
      set(state => ({
        questions: [...state.questions, newQuestion],
        isLoading: false
      }));
    } catch (error) {
      set({ 
        error: error instanceof Error ? error.message : 'Failed to create question', 
        isLoading: false 
      });
    }
  },
  
  updateQuestion: async (id, question) => {
    set({ isLoading: true, error: null });
    try {
      const updatedQuestion = await apiUpdateQuestion(id, question);
      set(state => ({
        questions: state.questions.map(q => q.id === id ? updatedQuestion : q),
        isLoading: false
      }));
    } catch (error) {
      set({ 
        error: error instanceof Error ? error.message : 'Failed to update question', 
        isLoading: false 
      });
    }
  },
  
  deleteQuestion: async (id) => {
    set({ isLoading: true, error: null });
    try {
      await apiDeleteQuestion(id);
      set(state => ({
        questions: state.questions.filter(q => q.id !== id),
        isLoading: false
      }));
    } catch (error) {
      set({ 
        error: error instanceof Error ? error.message : 'Failed to delete question', 
        isLoading: false 
      });
    }
  },
}));