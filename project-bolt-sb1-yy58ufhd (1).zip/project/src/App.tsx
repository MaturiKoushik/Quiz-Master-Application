import { useEffect } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import Layout from './components/layout/Layout';
import AdminLayout from './components/layout/AdminLayout';
import Home from './pages/Home';
import Login from './pages/auth/Login';
import Register from './pages/auth/Register';
import Dashboard from './pages/user/Dashboard';
import QuizList from './pages/user/QuizList';
import TakeQuiz from './pages/user/TakeQuiz';
import Results from './pages/user/Results';
import AdminDashboard from './pages/admin/AdminDashboard';
import AdminQuizList from './pages/admin/AdminQuizList';
import CreateQuiz from './pages/admin/CreateQuiz';
import EditQuiz from './pages/admin/EditQuiz';
import Profile from './pages/user/Profile';
import NotFound from './pages/NotFound';
import { useAuthStore } from './store/authStore';
import ProtectedRoute from './components/auth/ProtectedRoute';
import AdminRoute from './components/auth/AdminRoute';

function App() {
  const { checkAuth } = useAuthStore();
  
  useEffect(() => {
    // Check if user is already logged in from local storage
    checkAuth();
  }, [checkAuth]);

  return (
    <Routes>
      <Route path="/" element={<Layout />}>
        <Route index element={<Home />} />
        <Route path="login" element={<Login />} />
        <Route path="register" element={<Register />} />
        
        {/* User Routes */}
        <Route element={<ProtectedRoute />}>
          <Route path="dashboard" element={<Dashboard />} />
          <Route path="quizzes" element={<QuizList />} />
          <Route path="quiz/:id" element={<TakeQuiz />} />
          <Route path="results/:id" element={<Results />} />
          <Route path="profile" element={<Profile />} />
        </Route>
        
        {/* Admin Routes */}
        <Route path="admin" element={
          <AdminRoute>
            <AdminLayout />
          </AdminRoute>
        }>
          <Route index element={<Navigate to="dashboard" replace />} />
          <Route path="dashboard" element={<AdminDashboard />} />
          <Route path="quizzes" element={<AdminQuizList />} />
          <Route path="quizzes/create" element={<CreateQuiz />} />
          <Route path="quizzes/edit/:id" element={<EditQuiz />} />
        </Route>
        
        <Route path="*" element={<NotFound />} />
      </Route>
    </Routes>
  );
}

export default App;