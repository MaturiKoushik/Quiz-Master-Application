export interface User {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'user';
  createdAt: string;
}

export interface Quiz {
  id: string;
  title: string;
  description: string;
  timeLimit: number; // in minutes
  totalQuestions: number;
  difficulty: 'easy' | 'medium' | 'hard';
  createdBy: string;
  createdAt: string;
  isPublished: boolean;
}

export interface Question {
  id: string;
  quizId: string;
  text: string;
  type: 'multiple-choice' | 'true-false';
  options: Option[];
  correctOptionId: string;
  points: number;
}

export interface Option {
  id: string;
  text: string;
}

export interface QuizAttempt {
  id: string;
  quizId: string;
  userId: string;
  startedAt: string;
  completedAt: string | null;
  score: number;
  maxScore: number;
  answers: Answer[];
}

export interface Answer {
  questionId: string;
  selectedOptionId: string;
  isCorrect: boolean;
}

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;
  login: (email: string, password: string) => Promise<void>;
  register: (name: string, email: string, password: string) => Promise<void>;
  logout: () => void;
  checkAuth: () => void;
}

export interface QuizState {
  quizzes: Quiz[];
  currentQuiz: Quiz | null;
  questions: Question[];
  isLoading: boolean;
  error: string | null;
  fetchQuizzes: () => Promise<void>;
  fetchQuiz: (id: string) => Promise<void>;
  fetchQuestions: (quizId: string) => Promise<void>;
  createQuiz: (quiz: Omit<Quiz, 'id' | 'createdAt' | 'createdBy'>) => Promise<void>;
  updateQuiz: (id: string, quiz: Partial<Quiz>) => Promise<void>;
  deleteQuiz: (id: string) => Promise<void>;
  createQuestion: (question: Omit<Question, 'id'>) => Promise<void>;
  updateQuestion: (id: string, question: Partial<Question>) => Promise<void>;
  deleteQuestion: (id: string) => Promise<void>;
}

export interface QuizAttemptState {
  currentAttempt: QuizAttempt | null;
  attempts: QuizAttempt[];
  isLoading: boolean;
  error: string | null;
  startQuiz: (quizId: string) => Promise<void>;
  submitAnswer: (questionId: string, selectedOptionId: string) => Promise<void>;
  completeQuiz: () => Promise<void>;
  fetchAttempts: (userId: string) => Promise<void>;
  fetchAttempt: (attemptId: string) => Promise<void>;
}