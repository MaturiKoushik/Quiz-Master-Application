import { Quiz, Question } from '../types';

// This is a mock service - in a real app, you would call your Java backend API
// Replace the implementation with actual API calls

const API_URL = 'http://localhost:8080/api';

// Mock data
const mockQuizzes: Quiz[] = [
  {
    id: '1',
    title: 'JavaScript Fundamentals',
    description: 'Test your knowledge of JavaScript fundamentals',
    timeLimit: 15,
    totalQuestions: 10,
    difficulty: 'medium',
    createdBy: '1',
    createdAt: '2025-05-10T12:00:00Z',
    isPublished: true
  },
  {
    id: '2',
    title: 'React Basics',
    description: 'A quiz about React fundamentals and hooks',
    timeLimit: 20,
    totalQuestions: 15,
    difficulty: 'medium',
    createdBy: '1',
    createdAt: '2025-05-11T10:30:00Z',
    isPublished: true
  },
  {
    id: '3',
    title: 'Database Concepts',
    description: 'Test your knowledge about database fundamentals',
    timeLimit: 30,
    totalQuestions: 20,
    difficulty: 'hard',
    createdBy: '1',
    createdAt: '2025-05-12T09:15:00Z',
    isPublished: true
  }
];

const mockQuestions: Question[] = [
  {
    id: '1',
    quizId: '1',
    text: 'What is JavaScript?',
    type: 'multiple-choice',
    options: [
      { id: 'a', text: 'A programming language' },
      { id: 'b', text: 'A markup language' },
      { id: 'c', text: 'A database' },
      { id: 'd', text: 'An operating system' }
    ],
    correctOptionId: 'a',
    points: 10
  },
  {
    id: '2',
    quizId: '1',
    text: 'Is JavaScript case-sensitive?',
    type: 'true-false',
    options: [
      { id: 'true', text: 'True' },
      { id: 'false', text: 'False' }
    ],
    correctOptionId: 'true',
    points: 5
  }
];

export const fetchQuizzes = async (): Promise<Quiz[]> => {
  // Simulate API call delay
  await new Promise(resolve => setTimeout(resolve, 500));
  
  // Return mock data
  return [...mockQuizzes];
};

export const fetchQuiz = async (id: string): Promise<Quiz> => {
  // Simulate API call delay
  await new Promise(resolve => setTimeout(resolve, 300));
  
  const quiz = mockQuizzes.find(q => q.id === id);
  if (!quiz) {
    throw new Error('Quiz not found');
  }
  
  return { ...quiz };
};

export const fetchQuestions = async (quizId: string): Promise<Question[]> => {
  // Simulate API call delay
  await new Promise(resolve => setTimeout(resolve, 400));
  
  // Filter questions by quizId
  const questions = mockQuestions.filter(q => q.quizId === quizId);
  
  return [...questions];
};

export const createQuiz = async (quiz: Omit<Quiz, 'id' | 'createdAt' | 'createdBy'>): Promise<Quiz> => {
  // Simulate API call delay
  await new Promise(resolve => setTimeout(resolve, 600));
  
  const newQuiz: Quiz = {
    ...quiz,
    id: Math.random().toString(36).substr(2, 9),
    createdBy: '1', // Assuming user with ID 1 is creating
    createdAt: new Date().toISOString()
  };
  
  // In a real application, you would make an API call to save the quiz
  
  return newQuiz;
};

export const updateQuiz = async (id: string, quiz: Partial<Quiz>): Promise<Quiz> => {
  // Simulate API call delay
  await new Promise(resolve => setTimeout(resolve, 500));
  
  const existingQuiz = mockQuizzes.find(q => q.id === id);
  if (!existingQuiz) {
    throw new Error('Quiz not found');
  }
  
  const updatedQuiz = { ...existingQuiz, ...quiz };
  
  // In a real application, you would make an API call to update the quiz
  
  return updatedQuiz;
};

export const deleteQuiz = async (id: string): Promise<void> => {
  // Simulate API call delay
  await new Promise(resolve => setTimeout(resolve, 400));
  
  // In a real application, you would make an API call to delete the quiz
  
  return;
};

export const createQuestion = async (question: Omit<Question, 'id'>): Promise<Question> => {
  // Simulate API call delay
  await new Promise(resolve => setTimeout(resolve, 500));
  
  const newQuestion: Question = {
    ...question,
    id: Math.random().toString(36).substr(2, 9)
  };
  
  // In a real application, you would make an API call to save the question
  
  return newQuestion;
};

export const updateQuestion = async (id: string, question: Partial<Question>): Promise<Question> => {
  // Simulate API call delay
  await new Promise(resolve => setTimeout(resolve, 400));
  
  const existingQuestion = mockQuestions.find(q => q.id === id);
  if (!existingQuestion) {
    throw new Error('Question not found');
  }
  
  const updatedQuestion = { ...existingQuestion, ...question };
  
  // In a real application, you would make an API call to update the question
  
  return updatedQuestion;
};

export const deleteQuestion = async (id: string): Promise<void> => {
  // Simulate API call delay
  await new Promise(resolve => setTimeout(resolve, 300));
  
  // In a real application, you would make an API call to delete the question
  
  return;
};