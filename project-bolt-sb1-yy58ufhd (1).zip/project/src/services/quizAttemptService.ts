import { QuizAttempt, Answer } from '../types';

// This is a mock service - in a real app, you would call your Java backend API
// Replace the implementation with actual API calls

const API_URL = 'http://localhost:8080/api';

// Mock data
const mockAttempts: QuizAttempt[] = [
  {
    id: '1',
    quizId: '1',
    userId: '2',
    startedAt: '2025-05-15T14:30:00Z',
    completedAt: '2025-05-15T14:45:00Z',
    score: 80,
    maxScore: 100,
    answers: [
      {
        questionId: '1',
        selectedOptionId: 'a',
        isCorrect: true
      },
      {
        questionId: '2',
        selectedOptionId: 'true',
        isCorrect: true
      }
    ]
  }
];

export const startQuiz = async (quizId: string): Promise<QuizAttempt> => {
  // Simulate API call delay
  await new Promise(resolve => setTimeout(resolve, 500));
  
  // Create a new attempt
  const newAttempt: QuizAttempt = {
    id: Math.random().toString(36).substr(2, 9),
    quizId,
    userId: '2', // Assuming user with ID 2 is taking the quiz
    startedAt: new Date().toISOString(),
    completedAt: null,
    score: 0,
    maxScore: 100, // This would be calculated based on the questions
    answers: []
  };
  
  // In a real application, you would make an API call to create the attempt
  
  return newAttempt;
};

export const submitAnswer = async (
  attemptId: string,
  questionId: string,
  selectedOptionId: string
): Promise<QuizAttempt> => {
  // Simulate API call delay
  await new Promise(resolve => setTimeout(resolve, 300));
  
  // Find the attempt
  const attempt = mockAttempts.find(a => a.id === attemptId) || {
    id: attemptId,
    quizId: '1',
    userId: '2',
    startedAt: new Date().toISOString(),
    completedAt: null,
    score: 0,
    maxScore: 100,
    answers: []
  };
  
  // Simulate checking if the answer is correct
  // In a real application, this would be done on the backend
  const isCorrect = Math.random() > 0.3; // Random for demo
  
  // Add the answer
  const answer: Answer = {
    questionId,
    selectedOptionId,
    isCorrect
  };
  
  const updatedAttempt: QuizAttempt = {
    ...attempt,
    answers: [...attempt.answers.filter(a => a.questionId !== questionId), answer]
  };
  
  // In a real application, you would make an API call to update the attempt
  
  return updatedAttempt;
};

export const completeQuiz = async (attemptId: string): Promise<QuizAttempt> => {
  // Simulate API call delay
  await new Promise(resolve => setTimeout(resolve, 600));
  
  // Find the attempt
  const attempt = mockAttempts.find(a => a.id === attemptId) || {
    id: attemptId,
    quizId: '1',
    userId: '2',
    startedAt: new Date(Date.now() - 10 * 60000).toISOString(), // 10 minutes ago
    completedAt: null,
    score: 0,
    maxScore: 100,
    answers: []
  };
  
  // Calculate the score
  const correctAnswers = attempt.answers.filter(a => a.isCorrect).length;
  const totalQuestions = 10; // This would be the actual number of questions
  const score = Math.round((correctAnswers / totalQuestions) * 100);
  
  const completedAttempt: QuizAttempt = {
    ...attempt,
    completedAt: new Date().toISOString(),
    score
  };
  
  // In a real application, you would make an API call to complete the attempt
  
  return completedAttempt;
};

export const fetchAttempts = async (userId: string): Promise<QuizAttempt[]> => {
  // Simulate API call delay
  await new Promise(resolve => setTimeout(resolve, 500));
  
  // Filter attempts by userId
  const attempts = mockAttempts.filter(a => a.userId === userId);
  
  return [...attempts];
};

export const fetchAttempt = async (attemptId: string): Promise<QuizAttempt> => {
  // Simulate API call delay
  await new Promise(resolve => setTimeout(resolve, 400));
  
  const attempt = mockAttempts.find(a => a.id === attemptId);
  if (!attempt) {
    throw new Error('Attempt not found');
  }
  
  return { ...attempt };
};