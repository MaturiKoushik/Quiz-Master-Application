import { User } from '../types';

// This is a mock service - in a real app, you would call your Java backend API
// Replace the implementation with actual API calls

const API_URL = 'http://localhost:8080/api';

export const apiLogin = async (email: string, password: string): Promise<User> => {
  // For demo purposes, return mock data
  // In a real application, you would make an API call here
  
  // Simulate API call delay
  await new Promise(resolve => setTimeout(resolve, 500));
  
  // For demo, we'll use hardcoded responses
  if (email === 'admin@example.com' && password === 'password') {
    return {
      id: '1',
      name: 'Admin User',
      email: 'admin@example.com',
      role: 'admin',
      createdAt: new Date().toISOString()
    };
  } else if (email === 'user@example.com' && password === 'password') {
    return {
      id: '2',
      name: 'Regular User',
      email: 'user@example.com',
      role: 'user',
      createdAt: new Date().toISOString()
    };
  }
  
  throw new Error('Invalid email or password');
};

export const apiRegister = async (name: string, email: string, password: string): Promise<User> => {
  // Simulate API call delay
  await new Promise(resolve => setTimeout(resolve, 500));
  
  // In a real application, you would make an API call to register the user
  return {
    id: '3',
    name,
    email,
    role: 'user', // New registrations are always regular users
    createdAt: new Date().toISOString()
  };
};

export const apiLogout = async (): Promise<void> => {
  // Simulate API call delay
  await new Promise(resolve => setTimeout(resolve, 300));
  
  // In a real application, you would make an API call to invalidate the session
  return;
};

// In a real application, you would have a method to verify the token with the backend
export const verifyToken = async (token: string): Promise<User> => {
  // Simulate API call delay
  await new Promise(resolve => setTimeout(resolve, 300));
  
  // Mock implementation
  return {
    id: '2',
    name: 'Test User',
    email: 'user@example.com',
    role: 'user',
    createdAt: new Date().toISOString()
  };
};