import { useState, FormEvent } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuizStore } from '../../store/quizStore';
import { Save, X, Clock, AlertCircle } from 'lucide-react';

const CreateQuiz = () => {
  const navigate = useNavigate();
  const { createQuiz, isLoading, error } = useQuizStore();
  
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [timeLimit, setTimeLimit] = useState(15);
  const [difficulty, setDifficulty] = useState<'easy' | 'medium' | 'hard'>('medium');
  const [isFormValid, setIsFormValid] = useState(false);
  
  // Validate form on input change
  const validateForm = () => {
    const valid = title.trim() !== '' && description.trim() !== '' && timeLimit > 0;
    setIsFormValid(valid);
  };
  
  // Handle form input changes
  const handleTitleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setTitle(e.target.value);
    validateForm();
  };
  
  const handleDescriptionChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setDescription(e.target.value);
    validateForm();
  };
  
  const handleTimeLimitChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseInt(e.target.value, 10);
    setTimeLimit(isNaN(value) ? 0 : value);
    validateForm();
  };
  
  const handleDifficultyChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setDifficulty(e.target.value as 'easy' | 'medium' | 'hard');
  };
  
  // Handle form submission
  const handleSubmit = async (e: FormEvent, publish: boolean) => {
    e.preventDefault();
    
    if (!isFormValid) return;
    
    try {
      const newQuiz = await createQuiz({
        title,
        description,
        timeLimit,
        difficulty,
        totalQuestions: 0, // Will be updated when questions are added
        isPublished: publish,
      });
      
      // Redirect to edit page to add questions
      navigate(`/admin/quizzes/edit/${newQuiz?.id}`);
    } catch (error) {
      console.error('Error creating quiz:', error);
    }
  };
  
  return (
    <div className="animate-fadeIn">
      <div className="mb-8">
        <h1 className="mb-2">Create New Quiz</h1>
        <p className="text-gray-500">
          Set up the basic information for your new quiz, then add questions on the next screen.
        </p>
      </div>
      
      <div className="bg-white rounded-lg shadow-md overflow-hidden">
        {error && (
          <div className="bg-red-50 border-l-4 border-red-500 p-4 mb-6">
            <div className="flex items-start">
              <AlertCircle className="w-5 h-5 text-red-500 mr-2 mt-0.5" />
              <p className="text-red-700">{error}</p>
            </div>
          </div>
        )}
        
        <form onSubmit={(e) => handleSubmit(e, false)}>
          <div className="p-6 space-y-6">
            <div>
              <label htmlFor="title" className="block text-sm font-medium text-gray-700 mb-1">
                Quiz Title <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                id="title"
                className="input-field"
                placeholder="e.g., JavaScript Fundamentals Quiz"
                value={title}
                onChange={handleTitleChange}
                required
              />
            </div>
            
            <div>
              <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-1">
                Description <span className="text-red-500">*</span>
              </label>
              <textarea
                id="description"
                rows={4}
                className="input-field"
                placeholder="Provide a brief description of what this quiz covers..."
                value={description}
                onChange={handleDescriptionChange}
                required
              />
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label htmlFor="timeLimit" className="block text-sm font-medium text-gray-700 mb-1">
                  Time Limit (minutes) <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <input
                    type="number"
                    id="timeLimit"
                    min="1"
                    max="180"
                    className="input-field pl-10"
                    value={timeLimit}
                    onChange={handleTimeLimitChange}
                    required
                  />
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Clock className="h-5 w-5 text-gray-400" />
                  </div>
                </div>
                <p className="mt-1 text-sm text-gray-500">
                  How long users have to complete the quiz.
                </p>
              </div>
              
              <div>
                <label htmlFor="difficulty" className="block text-sm font-medium text-gray-700 mb-1">
                  Difficulty Level
                </label>
                <select
                  id="difficulty"
                  className="input-field"
                  value={difficulty}
                  onChange={handleDifficultyChange}
                >
                  <option value="easy">Easy</option>
                  <option value="medium">Medium</option>
                  <option value="hard">Hard</option>
                </select>
              </div>
            </div>
            
            <div className="bg-yellow-50 p-4 rounded-md">
              <div className="flex">
                <div className="flex-shrink-0">
                  <AlertCircle className="h-5 w-5 text-yellow-600" />
                </div>
                <div className="ml-3">
                  <h3 className="text-sm font-medium text-yellow-800">Important Note</h3>
                  <div className="mt-2 text-sm text-yellow-700">
                    <p>
                      After creating the quiz, you'll be redirected to add questions. A quiz must have at least one question before it can be published.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <div className="px-6 py-4 bg-gray-50 flex justify-end space-x-3">
            <button
              type="button"
              onClick={() => navigate('/admin/quizzes')}
              className="btn btn-outline flex items-center"
            >
              <X className="w-4 h-4 mr-2" />
              Cancel
            </button>
            
            <button
              type="submit"
              className="btn btn-primary flex items-center"
              disabled={!isFormValid || isLoading}
            >
              {isLoading ? (
                <div className="flex items-center">
                  <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></span>
                  <span>Creating...</span>
                </div>
              ) : (
                <>
                  <Save className="w-4 h-4 mr-2" />
                  <span>Create Quiz</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default CreateQuiz;