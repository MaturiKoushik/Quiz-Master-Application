import { useEffect, useState, FormEvent } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useQuizStore } from '../../store/quizStore';
import { Save, PlusCircle, Trash, ArrowUp, ArrowDown, AlertCircle, Clock, Eye, CheckCircle, X } from 'lucide-react';

const EditQuiz = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const {
    currentQuiz,
    questions,
    fetchQuiz,
    fetchQuestions,
    updateQuiz,
    createQuestion,
    updateQuestion,
    deleteQuestion,
    isLoading,
    error
  } = useQuizStore();

  // Quiz details form state
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [timeLimit, setTimeLimit] = useState(15);
  const [difficulty, setDifficulty] = useState<'easy' | 'medium' | 'hard'>('medium');
  const [isPublished, setIsPublished] = useState(false);
  
  // Question form state
  const [showQuestionForm, setShowQuestionForm] = useState(false);
  const [editingQuestionId, setEditingQuestionId] = useState<string | null>(null);
  const [questionText, setQuestionText] = useState('');
  const [questionType, setQuestionType] = useState<'multiple-choice' | 'true-false'>('multiple-choice');
  const [options, setOptions] = useState<{ id: string; text: string }[]>([
    { id: '1', text: '' },
    { id: '2', text: '' },
    { id: '3', text: '' },
    { id: '4', text: '' }
  ]);
  const [correctOptionId, setCorrectOptionId] = useState('');
  const [points, setPoints] = useState(10);
  
  // Confirmation modals
  const [showDeleteQuestionModal, setShowDeleteQuestionModal] = useState(false);
  const [questionToDelete, setQuestionToDelete] = useState<string | null>(null);
  const [showPublishModal, setShowPublishModal] = useState(false);
  
  // Status alerts
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [publishSuccess, setPublishSuccess] = useState(false);

  // Fetch quiz and questions
  useEffect(() => {
    if (id) {
      fetchQuiz(id);
      fetchQuestions(id);
    }
  }, [id, fetchQuiz, fetchQuestions]);

  // Set form values when quiz is loaded
  useEffect(() => {
    if (currentQuiz) {
      setTitle(currentQuiz.title);
      setDescription(currentQuiz.description);
      setTimeLimit(currentQuiz.timeLimit);
      setDifficulty(currentQuiz.difficulty);
      setIsPublished(currentQuiz.isPublished);
    }
  }, [currentQuiz]);

  // Clear temporary success messages
  useEffect(() => {
    if (saveSuccess) {
      const timer = setTimeout(() => setSaveSuccess(false), 3000);
      return () => clearTimeout(timer);
    }
    if (publishSuccess) {
      const timer = setTimeout(() => setPublishSuccess(false), 3000);
      return () => clearTimeout(timer);
    }
  }, [saveSuccess, publishSuccess]);

  // Handle quiz details form submission
  const handleQuizSubmit = async (e: FormEvent) => {
    e.preventDefault();
    
    if (!id) return;
    
    try {
      await updateQuiz(id, {
        title,
        description,
        timeLimit,
        difficulty,
        isPublished
      });
      
      setSaveSuccess(true);
    } catch (error) {
      console.error('Error updating quiz:', error);
    }
  };

  // Handle publish quiz
  const handlePublishQuiz = async () => {
    if (!id) return;
    
    try {
      await updateQuiz(id, { isPublished: true });
      setIsPublished(true);
      setShowPublishModal(false);
      setPublishSuccess(true);
    } catch (error) {
      console.error('Error publishing quiz:', error);
    }
  };

  // Handle adding a new question
  const handleAddQuestion = () => {
    setShowQuestionForm(true);
    setEditingQuestionId(null);
    resetQuestionForm();
  };

  // Handle editing a question
  const handleEditQuestion = (question: any) => {
    setShowQuestionForm(true);
    setEditingQuestionId(question.id);
    setQuestionText(question.text);
    setQuestionType(question.type);
    setOptions(question.options);
    setCorrectOptionId(question.correctOptionId);
    setPoints(question.points);
  };

  // Reset question form values
  const resetQuestionForm = () => {
    setQuestionText('');
    setQuestionType('multiple-choice');
    setOptions([
      { id: '1', text: '' },
      { id: '2', text: '' },
      { id: '3', text: '' },
      { id: '4', text: '' }
    ]);
    setCorrectOptionId('');
    setPoints(10);
  };

  // Handle question form submission
  const handleQuestionSubmit = async (e: FormEvent) => {
    e.preventDefault();
    
    if (!id) return;
    
    // Create options based on question type
    const finalOptions = questionType === 'true-false'
      ? [
          { id: 'true', text: 'True' },
          { id: 'false', text: 'False' }
        ]
      : options;
    
    // Validate form
    if (questionText.trim() === '') return;
    if (correctOptionId === '') return;
    if (questionType === 'multiple-choice' && options.some(o => o.text.trim() === '')) return;
    
    try {
      if (editingQuestionId) {
        // Update existing question
        await updateQuestion(editingQuestionId, {
          text: questionText,
          type: questionType,
          options: finalOptions,
          correctOptionId,
          points
        });
      } else {
        // Create new question
        await createQuestion({
          quizId: id,
          text: questionText,
          type: questionType,
          options: finalOptions,
          correctOptionId,
          points
        });
        
        // Update quiz with new question count
        await updateQuiz(id, {
          totalQuestions: questions.length + 1
        });
      }
      
      // Reset form and close
      setShowQuestionForm(false);
      resetQuestionForm();
    } catch (error) {
      console.error('Error saving question:', error);
    }
  };

  // Handle delete question confirmation
  const handleDeleteQuestion = async () => {
    if (!questionToDelete) return;
    
    try {
      await deleteQuestion(questionToDelete);
      
      // Update quiz with new question count
      if (id) {
        await updateQuiz(id, {
          totalQuestions: questions.length - 1
        });
      }
      
      setShowDeleteQuestionModal(false);
      setQuestionToDelete(null);
    } catch (error) {
      console.error('Error deleting question:', error);
    }
  };

  // Handle option input change
  const handleOptionChange = (index: number, value: string) => {
    const newOptions = [...options];
    newOptions[index].text = value;
    setOptions(newOptions);
  };

  // Add a new option
  const handleAddOption = () => {
    if (options.length >= 8) return; // Limit to 8 options
    
    const newId = (options.length + 1).toString();
    setOptions([...options, { id: newId, text: '' }]);
  };

  // Remove an option
  const handleRemoveOption = (index: number) => {
    if (options.length <= 2) return; // Minimum 2 options
    
    const newOptions = options.filter((_, i) => i !== index);
    setOptions(newOptions);
    
    // If removing the correct option, reset correctOptionId
    if (options[index].id === correctOptionId) {
      setCorrectOptionId('');
    }
  };

  // Loading state
  if (isLoading && !currentQuiz) {
    return (
      <div className="min-h-[calc(100vh-64px)] flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-t-4 border-b-4 border-primary-600 rounded-full animate-spin mx-auto mb-4"></div>
          <h2 className="text-xl font-semibold text-gray-700 mb-2">Loading Quiz</h2>
          <p className="text-gray-500">Please wait while we load the quiz data...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="animate-fadeIn">
      <div className="mb-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="mb-2">Edit Quiz</h1>
            <p className="text-gray-500">
              Update quiz details and manage questions.
            </p>
          </div>
          
          <div className="flex flex-wrap gap-2">
            {currentQuiz?.isPublished ? (
              <div className="px-3 py-1.5 bg-green-100 text-green-800 rounded-full flex items-center">
                <CheckCircle className="w-4 h-4 mr-1.5" />
                <span>Published</span>
              </div>
            ) : (
              <button
                onClick={() => setShowPublishModal(true)}
                className="btn btn-primary px-3 py-1.5"
                disabled={questions.length === 0}
              >
                Publish Quiz
              </button>
            )}
            
            <button
              onClick={() => navigate(`/quiz/${id}`)}
              className="btn btn-outline px-3 py-1.5 flex items-center"
            >
              <Eye className="w-4 h-4 mr-1.5" />
              <span>Preview</span>
            </button>
          </div>
        </div>
      </div>
      
      {/* Success Messages */}
      {saveSuccess && (
        <div className="mb-6 bg-green-50 border-l-4 border-green-500 p-4 animate-fadeIn">
          <div className="flex">
            <div className="flex-shrink-0">
              <CheckCircle className="h-5 w-5 text-green-500" />
            </div>
            <div className="ml-3">
              <p className="text-sm text-green-700">
                Quiz details saved successfully!
              </p>
            </div>
          </div>
        </div>
      )}
      
      {publishSuccess && (
        <div className="mb-6 bg-green-50 border-l-4 border-green-500 p-4 animate-fadeIn">
          <div className="flex">
            <div className="flex-shrink-0">
              <CheckCircle className="h-5 w-5 text-green-500" />
            </div>
            <div className="ml-3">
              <p className="text-sm text-green-700">
                Your quiz has been published successfully!
              </p>
            </div>
          </div>
        </div>
      )}
      
      {/* Error Message */}
      {error && (
        <div className="mb-6 bg-red-50 border-l-4 border-red-500 p-4">
          <div className="flex">
            <div className="flex-shrink-0">
              <AlertCircle className="h-5 w-5 text-red-500" />
            </div>
            <div className="ml-3">
              <p className="text-sm text-red-700">{error}</p>
            </div>
          </div>
        </div>
      )}
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Quiz Details Form */}
        <div className="lg:col-span-1">
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="p-6 border-b border-gray-200">
              <h2 className="text-lg font-semibold">Quiz Details</h2>
            </div>
            
            <form onSubmit={handleQuizSubmit}>
              <div className="p-6 space-y-6">
                <div>
                  <label htmlFor="title" className="block text-sm font-medium text-gray-700 mb-1">
                    Quiz Title <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    id="title"
                    className="input-field"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    required
                  />
                </div>
                
                <div>
                  <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-1">
                    Description <span className="text-red-500">*</span>
                  </label>
                  <textarea
                    id="description"
                    rows={4}
                    className="input-field"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    required
                  />
                </div>
                
                <div>
                  <label htmlFor="timeLimit" className="block text-sm font-medium text-gray-700 mb-1">
                    Time Limit (minutes) <span className="text-red-500">*</span>
                  </label>
                  <div className="relative">
                    <input
                      type="number"
                      id="timeLimit"
                      min="1"
                      max="180"
                      className="input-field pl-10"
                      value={timeLimit}
                      onChange={(e) => setTimeLimit(parseInt(e.target.value) || 0)}
                      required
                    />
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <Clock className="h-5 w-5 text-gray-400" />
                    </div>
                  </div>
                </div>
                
                <div>
                  <label htmlFor="difficulty" className="block text-sm font-medium text-gray-700 mb-1">
                    Difficulty Level
                  </label>
                  <select
                    id="difficulty"
                    className="input-field"
                    value={difficulty}
                    onChange={(e) => setDifficulty(e.target.value as 'easy' | 'medium' | 'hard')}
                  >
                    <option value="easy">Easy</option>
                    <option value="medium">Medium</option>
                    <option value="hard">Hard</option>
                  </select>
                </div>
              </div>
              
              <div className="p-6 bg-gray-50 flex justify-between">
                <button
                  type="button"
                  onClick={() => navigate('/admin/quizzes')}
                  className="btn btn-outline"
                >
                  Back to List
                </button>
                
                <button
                  type="submit"
                  className="btn btn-primary flex items-center"
                  disabled={isLoading}
                >
                  <Save className="w-4 h-4 mr-2" />
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
        
        {/* Questions List */}
        <div className="lg:col-span-2">
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="p-6 border-b border-gray-200 flex justify-between items-center">
              <h2 className="text-lg font-semibold">Questions</h2>
              
              <button
                onClick={handleAddQuestion}
                className="btn btn-primary flex items-center"
              >
                <PlusCircle className="w-4 h-4 mr-2" />
                Add Question
              </button>
            </div>
            
            <div className="divide-y">
              {questions.length === 0 ? (
                <div className="p-12 text-center">
                  <AlertCircle className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-xl font-medium text-gray-900 mb-2">No questions yet</h3>
                  <p className="text-gray-500 max-w-md mx-auto mb-6">
                    This quiz doesn't have any questions yet. Add questions to make your quiz complete.
                  </p>
                  <button
                    onClick={handleAddQuestion}
                    className="btn btn-primary flex items-center mx-auto"
                  >
                    <PlusCircle className="w-4 h-4 mr-2" />
                    Add First Question
                  </button>
                </div>
              ) : (
                questions.map((question, index) => (
                  <div key={question.id} className="p-6 hover:bg-gray-50 transition-colors">
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <div className="flex items-center mb-2">
                          <span className="bg-primary-100 text-primary-800 text-sm font-medium px-2 py-0.5 rounded mr-2">
                            Q{index + 1}
                          </span>
                          <span className="text-sm text-gray-500 capitalize">
                            {question.type === 'multiple-choice' ? 'Multiple Choice' : 'True/False'}
                          </span>
                          <span className="mx-2 text-gray-300">|</span>
                          <span className="text-sm text-gray-500">
                            {question.points} {question.points === 1 ? 'point' : 'points'}
                          </span>
                        </div>
                        <p className="font-medium mb-3">{question.text}</p>
                        
                        <div className="space-y-2 mb-4">
                          {question.options.map((option) => (
                            <div
                              key={option.id}
                              className={`px-3 py-2 rounded-md text-sm ${
                                option.id === question.correctOptionId
                                  ? 'bg-green-100 text-green-800 border border-green-200'
                                  : 'bg-gray-100 text-gray-800'
                              }`}
                            >
                              {option.text}
                              {option.id === question.correctOptionId && (
                                <span className="ml-2 text-xs">(Correct)</span>
                              )}
                            </div>
                          ))}
                        </div>
                      </div>
                      
                      <div className="flex space-x-2 ml-4">
                        <button
                          onClick={() => handleEditQuestion(question)}
                          className="text-gray-600 hover:text-primary-600 transition-colors"
                          title="Edit Question"
                        >
                          <Edit className="w-5 h-5" />
                        </button>
                        <button
                          onClick={() => {
                            setQuestionToDelete(question.id);
                            setShowDeleteQuestionModal(true);
                          }}
                          className="text-gray-600 hover:text-red-600 transition-colors"
                          title="Delete Question"
                        >
                          <Trash className="w-5 h-5" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
      
      {/* Question Form Modal */}
      {showQuestionForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-xl max-w-3xl w-full max-h-[90vh] overflow-y-auto animate-fadeIn">
            <div className="p-6 border-b border-gray-200">
              <h3 className="text-lg font-semibold">
                {editingQuestionId ? 'Edit Question' : 'Add New Question'}
              </h3>
            </div>
            
            <form onSubmit={handleQuestionSubmit}>
              <div className="p-6 space-y-6">
                <div>
                  <label htmlFor="questionText" className="block text-sm font-medium text-gray-700 mb-1">
                    Question Text <span className="text-red-500">*</span>
                  </label>
                  <textarea
                    id="questionText"
                    rows={3}
                    className="input-field"
                    placeholder="Enter the question text here..."
                    value={questionText}
                    onChange={(e) => setQuestionText(e.target.value)}
                    required
                  />
                </div>
                
                <div>
                  <label htmlFor="questionType" className="block text-sm font-medium text-gray-700 mb-1">
                    Question Type
                  </label>
                  <select
                    id="questionType"
                    className="input-field"
                    value={questionType}
                    onChange={(e) => setQuestionType(e.target.value as 'multiple-choice' | 'true-false')}
                  >
                    <option value="multiple-choice">Multiple Choice</option>
                    <option value="true-false">True/False</option>
                  </select>
                </div>
                
                {questionType === 'multiple-choice' ? (
                  <div>
                    <div className="flex justify-between items-center mb-2">
                      <label className="block text-sm font-medium text-gray-700">
                        Answer Options <span className="text-red-500">*</span>
                      </label>
                      
                      <button
                        type="button"
                        onClick={handleAddOption}
                        className="text-sm text-primary-600 hover:text-primary-700 flex items-center"
                        disabled={options.length >= 8}
                      >
                        <PlusCircle className="w-4 h-4 mr-1" />
                        Add Option
                      </button>
                    </div>
                    
                    <div className="space-y-3">
                      {options.map((option, index) => (
                        <div key={index} className="flex items-center space-x-2">
                          <input
                            type="radio"
                            id={`option-${index}`}
                            name="correctOption"
                            className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300"
                            checked={correctOptionId === option.id}
                            onChange={() => setCorrectOptionId(option.id)}
                            required
                          />
                          <input
                            type="text"
                            className="input-field flex-grow"
                            placeholder={`Option ${index + 1}`}
                            value={option.text}
                            onChange={(e) => handleOptionChange(index, e.target.value)}
                            required
                          />
                          {options.length > 2 && (
                            <button
                              type="button"
                              onClick={() => handleRemoveOption(index)}
                              className="text-gray-400 hover:text-red-500"
                            >
                              <X className="w-5 h-5" />
                            </button>
                          )}
                        </div>
                      ))}
                    </div>
                    <p className="mt-2 text-sm text-gray-500">
                      Select the radio button next to the correct answer.
                    </p>
                  </div>
                ) : (
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Correct Answer <span className="text-red-500">*</span>
                    </label>
                    <div className="space-x-4">
                      <label className="inline-flex items-center">
                        <input
                          type="radio"
                          className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300"
                          name="trueFalse"
                          value="true"
                          checked={correctOptionId === 'true'}
                          onChange={() => setCorrectOptionId('true')}
                          required
                        />
                        <span className="ml-2">True</span>
                      </label>
                      <label className="inline-flex items-center">
                        <input
                          type="radio"
                          className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300"
                          name="trueFalse"
                          value="false"
                          checked={correctOptionId === 'false'}
                          onChange={() => setCorrectOptionId('false')}
                          required
                        />
                        <span className="ml-2">False</span>
                      </label>
                    </div>
                  </div>
                )}
                
                <div>
                  <label htmlFor="points" className="block text-sm font-medium text-gray-700 mb-1">
                    Points
                  </label>
                  <input
                    type="number"
                    id="points"
                    min="1"
                    max="100"
                    className="input-field w-full sm:w-32"
                    value={points}
                    onChange={(e) => setPoints(parseInt(e.target.value) || 0)}
                  />
                </div>
              </div>
              
              <div className="p-6 bg-gray-50 flex justify-end space-x-3">
                <button
                  type="button"
                  onClick={() => {
                    setShowQuestionForm(false);
                    resetQuestionForm();
                  }}
                  className="btn btn-outline"
                >
                  Cancel
                </button>
                
                <button
                  type="submit"
                  className="btn btn-primary"
                >
                  {editingQuestionId ? 'Update Question' : 'Add Question'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
      
      {/* Delete Question Confirmation Modal */}
      {showDeleteQuestionModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-xl max-w-md w-full animate-fadeIn">
            <div className="p-6">
              <div className="flex items-center text-red-600 mb-4">
                <AlertCircle className="w-6 h-6 mr-2" />
                <h3 className="text-lg font-bold">Delete Question?</h3>
              </div>
              <p className="mb-6">
                Are you sure you want to delete this question? This action cannot be undone.
              </p>
              <div className="flex justify-end space-x-3">
                <button
                  onClick={() => {
                    setShowDeleteQuestionModal(false);
                    setQuestionToDelete(null);
                  }}
                  className="btn btn-outline"
                >
                  Cancel
                </button>
                <button
                  onClick={handleDeleteQuestion}
                  className="btn bg-red-600 text-white hover:bg-red-700 focus:ring-red-500"
                >
                  Delete Question
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
      
      {/* Publish Quiz Confirmation Modal */}
      {showPublishModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-xl max-w-md w-full animate-fadeIn">
            <div className="p-6">
              <div className="flex items-center text-primary-600 mb-4">
                <AlertCircle className="w-6 h-6 mr-2" />
                <h3 className="text-lg font-bold">Publish Quiz?</h3>
              </div>
              <p className="mb-4">
                Publishing will make this quiz available to all users. Are you sure you want to proceed?
              </p>
              <div className="bg-yellow-50 p-4 rounded-md mb-6">
                <div className="flex">
                  <div className="flex-shrink-0">
                    <AlertCircle className="h-5 w-5 text-yellow-600" />
                  </div>
                  <div className="ml-3">
                    <p className="text-sm text-yellow-700">
                      Make sure you've reviewed all questions and answers carefully before publishing.
                    </p>
                  </div>
                </div>
              </div>
              <div className="flex justify-end space-x-3">
                <button
                  onClick={() => setShowPublishModal(false)}
                  className="btn btn-outline"
                >
                  Cancel
                </button>
                <button
                  onClick={handlePublishQuiz}
                  className="btn btn-primary"
                >
                  Publish Quiz
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default EditQuiz;