import { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useQuizStore } from '../../store/quizStore';
import { useAuthStore } from '../../store/authStore';
import { BookOpen, Users, Activity, PlusCircle, Trash, Edit } from 'lucide-react';

const AdminDashboard = () => {
  const { user } = useAuthStore();
  const { quizzes, fetchQuizzes, isLoading } = useQuizStore();
  
  useEffect(() => {
    fetchQuizzes();
  }, [fetchQuizzes]);
  
  // Calculate stats
  const totalQuizzes = quizzes.length;
  const publishedQuizzes = quizzes.filter(q => q.isPublished).length;
  const unpublishedQuizzes = totalQuizzes - publishedQuizzes;
  
  // Get recent quizzes for the admin dashboard
  const recentQuizzes = quizzes
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, 5);
  
  return (
    <div className="animate-fadeIn">
      <div className="flex flex-col md:flex-row md:items-center justify-between mb-8">
        <div>
          <h1 className="mb-2">Admin Dashboard</h1>
          <p className="text-gray-500">
            Welcome back, {user?.name}. Here's what's happening with your quizzes.
          </p>
        </div>
        
        <div className="mt-4 md:mt-0">
          <Link
            to="/admin/quizzes/create"
            className="btn btn-primary flex items-center"
          >
            <PlusCircle className="w-5 h-5 mr-2" />
            <span>Create New Quiz</span>
          </Link>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center">
            <div className="bg-primary-100 p-3 rounded-full mr-4">
              <BookOpen className="w-6 h-6 text-primary-600" />
            </div>
            <div>
              <p className="text-sm text-gray-500">Total Quizzes</p>
              <h3 className="text-2xl font-bold">{totalQuizzes}</h3>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center">
            <div className="bg-green-100 p-3 rounded-full mr-4">
              <Activity className="w-6 h-6 text-green-600" />
            </div>
            <div>
              <p className="text-sm text-gray-500">Published Quizzes</p>
              <h3 className="text-2xl font-bold">{publishedQuizzes}</h3>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center">
            <div className="bg-yellow-100 p-3 rounded-full mr-4">
              <BookOpen className="w-6 h-6 text-yellow-600" />
            </div>
            <div>
              <p className="text-sm text-gray-500">Drafts</p>
              <h3 className="text-2xl font-bold">{unpublishedQuizzes}</h3>
            </div>
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div>
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="p-6 border-b border-gray-200">
              <h2 className="text-xl font-bold">Recent Quizzes</h2>
            </div>
            
            {isLoading ? (
              <div className="p-6 animate-pulse space-y-4">
                {[...Array(3)].map((_, index) => (
                  <div key={index} className="border rounded-lg p-4">
                    <div className="h-4 bg-gray-200 rounded w-1/2 mb-4"></div>
                    <div className="h-4 bg-gray-200 rounded w-1/4 mb-2"></div>
                    <div className="h-4 bg-gray-200 rounded w-1/3"></div>
                  </div>
                ))}
              </div>
            ) : recentQuizzes.length > 0 ? (
              <div className="divide-y">
                {recentQuizzes.map((quiz) => (
                  <div key={quiz.id} className="p-6 hover:bg-gray-50 transition-colors">
                    <div className="flex justify-between items-start mb-2">
                      <h3 className="font-semibold">{quiz.title}</h3>
                      <div className={`px-2 py-1 text-xs font-medium rounded-full ${
                        quiz.isPublished
                          ? 'bg-green-100 text-green-800'
                          : 'bg-yellow-100 text-yellow-800'
                      }`}>
                        {quiz.isPublished ? 'Published' : 'Draft'}
                      </div>
                    </div>
                    <p className="text-gray-600 text-sm mb-3 line-clamp-2">
                      {quiz.description}
                    </p>
                    <div className="flex justify-between items-center">
                      <div className="text-sm text-gray-500">
                        Created: {new Date(quiz.createdAt).toLocaleDateString()}
                      </div>
                      <div className="flex space-x-2">
                        <Link
                          to={`/admin/quizzes/edit/${quiz.id}`}
                          className="text-gray-600 hover:text-primary-600 transition-colors"
                        >
                          <Edit className="w-5 h-5" />
                        </Link>
                        <button className="text-gray-600 hover:text-red-600 transition-colors">
                          <Trash className="w-5 h-5" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-12 text-center">
                <BookOpen className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-xl font-medium text-gray-900 mb-2">No quizzes yet</h3>
                <p className="text-gray-500 max-w-md mx-auto mb-6">
                  You haven't created any quizzes yet. Create your first quiz to get started!
                </p>
                <Link to="/admin/quizzes/create" className="btn btn-primary">
                  Create Your First Quiz
                </Link>
              </div>
            )}
          </div>
        </div>
        
        <div>
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="p-6 border-b border-gray-200">
              <h2 className="text-xl font-bold">Quick Actions</h2>
            </div>
            
            <div className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Link
                  to="/admin/quizzes/create"
                  className="p-4 border border-gray-200 rounded-lg hover:border-primary-500 hover:bg-primary-50 transition-colors flex items-center"
                >
                  <div className="w-10 h-10 rounded-full bg-primary-100 flex items-center justify-center mr-3">
                    <PlusCircle className="w-5 h-5 text-primary-600" />
                  </div>
                  <div>
                    <h3 className="font-medium">Create New Quiz</h3>
                    <p className="text-sm text-gray-500">Add a new quiz to your collection</p>
                  </div>
                </Link>
                
                <Link
                  to="/admin/quizzes"
                  className="p-4 border border-gray-200 rounded-lg hover:border-primary-500 hover:bg-primary-50 transition-colors flex items-center"
                >
                  <div className="w-10 h-10 rounded-full bg-primary-100 flex items-center justify-center mr-3">
                    <BookOpen className="w-5 h-5 text-primary-600" />
                  </div>
                  <div>
                    <h3 className="font-medium">Manage Quizzes</h3>
                    <p className="text-sm text-gray-500">Edit or delete existing quizzes</p>
                  </div>
                </Link>
                
                <div className="p-4 border border-gray-200 rounded-lg hover:border-primary-500 hover:bg-primary-50 transition-colors flex items-center cursor-pointer">
                  <div className="w-10 h-10 rounded-full bg-primary-100 flex items-center justify-center mr-3">
                    <Users className="w-5 h-5 text-primary-600" />
                  </div>
                  <div>
                    <h3 className="font-medium">User Analytics</h3>
                    <p className="text-sm text-gray-500">View quiz performance statistics</p>
                  </div>
                </div>
                
                <div className="p-4 border border-gray-200 rounded-lg hover:border-primary-500 hover:bg-primary-50 transition-colors flex items-center cursor-pointer">
                  <div className="w-10 h-10 rounded-full bg-primary-100 flex items-center justify-center mr-3">
                    <Activity className="w-5 h-5 text-primary-600" />
                  </div>
                  <div>
                    <h3 className="font-medium">Export Data</h3>
                    <p className="text-sm text-gray-500">Download quiz results and statistics</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow-md overflow-hidden mt-8">
            <div className="p-6 border-b border-gray-200">
              <h2 className="text-xl font-bold">System Status</h2>
            </div>
            
            <div className="p-6">
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-gray-600">Server Status</span>
                    <span className="text-green-600 font-medium">Operational</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div className="bg-green-500 h-2 rounded-full w-full"></div>
                  </div>
                </div>
                
                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-gray-600">Database</span>
                    <span className="text-green-600 font-medium">Connected</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div className="bg-green-500 h-2 rounded-full w-full"></div>
                  </div>
                </div>
                
                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-gray-600">Storage Usage</span>
                    <span className="font-medium">45%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div className="bg-blue-500 h-2 rounded-full w-[45%]"></div>
                  </div>
                </div>
                
                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-gray-600">API Health</span>
                    <span className="text-green-600 font-medium">Good</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div className="bg-green-500 h-2 rounded-full w-[95%]"></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;