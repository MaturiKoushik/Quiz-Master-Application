import { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuthStore } from '../../store/authStore';
import { useQuizAttemptStore } from '../../store/quizAttemptStore';
import { useQuizStore } from '../../store/quizStore';
import { BookOpen, Award, Clock, ArrowRight } from 'lucide-react';

const Dashboard = () => {
  const { user } = useAuthStore();
  const { attempts, fetchAttempts, isLoading: attemptsLoading } = useQuizAttemptStore();
  const { quizzes, fetchQuizzes, isLoading: quizzesLoading } = useQuizStore();
  
  useEffect(() => {
    if (user) {
      fetchAttempts(user.id);
      fetchQuizzes();
    }
  }, [user, fetchAttempts, fetchQuizzes]);
  
  // Calculate stats
  const totalAttempts = attempts.length;
  const totalCompleted = attempts.filter(a => a.completedAt).length;
  const averageScore = totalCompleted > 0
    ? attempts.reduce((sum, a) => sum + (a.score / a.maxScore) * 100, 0) / totalCompleted
    : 0;
  
  // Get recent quizzes
  const recentQuizzes = quizzes.slice(0, 3);
  
  // Get recent attempts
  const recentAttempts = [...attempts]
    .sort((a, b) => new Date(b.startedAt).getTime() - new Date(a.startedAt).getTime())
    .slice(0, 3);
  
  return (
    <div className="container-tight py-8 animate-fadeIn">
      <h1 className="mb-6">Welcome, {user?.name}</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center">
            <div className="bg-primary-100 p-3 rounded-full mr-4">
              <BookOpen className="w-6 h-6 text-primary-600" />
            </div>
            <div>
              <p className="text-sm text-gray-500">Total Attempts</p>
              <h3 className="text-2xl font-bold">{totalAttempts}</h3>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center">
            <div className="bg-secondary-100 p-3 rounded-full mr-4">
              <Award className="w-6 h-6 text-secondary-600" />
            </div>
            <div>
              <p className="text-sm text-gray-500">Average Score</p>
              <h3 className="text-2xl font-bold">{averageScore.toFixed(1)}%</h3>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center">
            <div className="bg-accent-100 p-3 rounded-full mr-4">
              <Clock className="w-6 h-6 text-accent-600" />
            </div>
            <div>
              <p className="text-sm text-gray-500">Completed Quizzes</p>
              <h3 className="text-2xl font-bold">{totalCompleted}</h3>
            </div>
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div>
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-bold">Recent Quizzes</h2>
            <Link to="/quizzes" className="text-primary-600 hover:text-primary-700 flex items-center">
              <span>View all</span>
              <ArrowRight className="ml-1 w-4 h-4" />
            </Link>
          </div>
          
          {quizzesLoading ? (
            <div className="bg-white rounded-lg shadow-md p-6 animate-pulse">
              <div className="h-4 bg-gray-200 rounded w-3/4 mb-4"></div>
              <div className="h-4 bg-gray-200 rounded w-1/2"></div>
            </div>
          ) : recentQuizzes.length > 0 ? (
            <div className="space-y-4">
              {recentQuizzes.map((quiz) => (
                <div key={quiz.id} className="quiz-card">
                  <div className="p-6">
                    <h3 className="font-semibold text-lg mb-2">{quiz.title}</h3>
                    <p className="text-gray-600 line-clamp-2 mb-4">{quiz.description}</p>
                    <div className="flex justify-between items-center">
                      <div className="flex items-center space-x-2 text-sm text-gray-500">
                        <Clock className="w-4 h-4" />
                        <span>{quiz.timeLimit} min</span>
                        <span>•</span>
                        <span className="capitalize">{quiz.difficulty}</span>
                      </div>
                      <Link
                        to={`/quiz/${quiz.id}`}
                        className="btn btn-primary px-3 py-1.5 text-sm"
                      >
                        Take Quiz
                      </Link>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="bg-white rounded-lg shadow-md p-6 text-center">
              <p className="text-gray-500">No quizzes available.</p>
            </div>
          )}
        </div>
        
        <div>
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-bold">Recent Attempts</h2>
            <Link to="/profile" className="text-primary-600 hover:text-primary-700 flex items-center">
              <span>View all</span>
              <ArrowRight className="ml-1 w-4 h-4" />
            </Link>
          </div>
          
          {attemptsLoading ? (
            <div className="bg-white rounded-lg shadow-md p-6 animate-pulse">
              <div className="h-4 bg-gray-200 rounded w-3/4 mb-4"></div>
              <div className="h-4 bg-gray-200 rounded w-1/2"></div>
            </div>
          ) : recentAttempts.length > 0 ? (
            <div className="space-y-4">
              {recentAttempts.map((attempt) => {
                const quiz = quizzes.find(q => q.id === attempt.quizId);
                const scorePercent = (attempt.score / attempt.maxScore) * 100;
                
                return (
                  <div key={attempt.id} className="bg-white rounded-lg shadow-md overflow-hidden">
                    <div className="p-6">
                      <h3 className="font-semibold text-lg mb-2">{quiz?.title || 'Quiz'}</h3>
                      <div className="flex justify-between items-center mb-3">
                        <div className="text-sm text-gray-500">
                          {new Date(attempt.startedAt).toLocaleDateString()}
                        </div>
                        {attempt.completedAt ? (
                          <div className="px-2 py-1 text-xs font-medium rounded-full text-green-800 bg-green-100">
                            Completed
                          </div>
                        ) : (
                          <div className="px-2 py-1 text-xs font-medium rounded-full text-yellow-800 bg-yellow-100">
                            In Progress
                          </div>
                        )}
                      </div>
                      {attempt.completedAt && (
                        <div className="mt-3">
                          <div className="flex justify-between mb-1 text-sm">
                            <span>Score</span>
                            <span>{scorePercent.toFixed(0)}%</span>
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-2">
                            <div
                              className={`h-2 rounded-full ${
                                scorePercent >= 70
                                  ? 'bg-green-500'
                                  : scorePercent >= 40
                                  ? 'bg-yellow-500'
                                  : 'bg-red-500'
                              }`}
                              style={{ width: `${scorePercent}%` }}
                            ></div>
                          </div>
                        </div>
                      )}
                      <div className="mt-4">
                        {attempt.completedAt ? (
                          <Link
                            to={`/results/${attempt.id}`}
                            className="btn btn-outline text-sm w-full"
                          >
                            View Results
                          </Link>
                        ) : (
                          <Link
                            to={`/quiz/${attempt.quizId}`}
                            className="btn btn-primary text-sm w-full"
                          >
                            Continue
                          </Link>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="bg-white rounded-lg shadow-md p-6 text-center">
              <p className="text-gray-500">No attempts yet. Start taking quizzes!</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;