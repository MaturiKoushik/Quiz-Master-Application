import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useQuizStore } from '../../store/quizStore';
import { useQuizAttemptStore } from '../../store/quizAttemptStore';
import { Clock, AlertTriangle, CheckCircle, HelpCircle } from 'lucide-react';

const TakeQuiz = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { currentQuiz, questions, fetchQuiz, fetchQuestions, isLoading: quizLoading } = useQuizStore();
  const { currentAttempt, startQuiz, submitAnswer, completeQuiz, isLoading: attemptLoading } = useQuizAttemptStore();
  
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [timeLeft, setTimeLeft] = useState<number | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Fetch quiz and questions
  useEffect(() => {
    if (id) {
      fetchQuiz(id);
      fetchQuestions(id);
    }
  }, [id, fetchQuiz, fetchQuestions]);
  
  // Start the quiz if not already started
  useEffect(() => {
    if (id && currentQuiz && !currentAttempt) {
      startQuiz(id);
    }
  }, [id, currentQuiz, currentAttempt, startQuiz]);
  
  // Set up timer
  useEffect(() => {
    if (currentQuiz && currentAttempt && !timeLeft) {
      // Calculate time left based on start time and time limit
      const startTime = new Date(currentAttempt.startedAt).getTime();
      const timeLimit = currentQuiz.timeLimit * 60 * 1000; // convert minutes to ms
      const now = new Date().getTime();
      const elapsed = now - startTime;
      const remaining = Math.max(0, timeLimit - elapsed);
      
      setTimeLeft(Math.floor(remaining / 1000)); // convert ms to seconds
    }
  }, [currentQuiz, currentAttempt, timeLeft]);
  
  // Timer countdown
  useEffect(() => {
    if (!timeLeft || timeLeft <= 0) return;
    
    const timer = setTimeout(() => {
      setTimeLeft(timeLeft - 1);
      
      // Auto-submit quiz when time runs out
      if (timeLeft === 1) {
        handleCompleteQuiz();
      }
    }, 1000);
    
    return () => clearTimeout(timer);
  }, [timeLeft]);
  
  // Get current question
  const currentQuestion = questions[currentQuestionIndex];
  
  // Format time display
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };
  
  // Check if the user has already answered this question
  useEffect(() => {
    if (currentQuestion && currentAttempt) {
      const answer = currentAttempt.answers.find(a => a.questionId === currentQuestion.id);
      if (answer) {
        setSelectedOption(answer.selectedOptionId);
      } else {
        setSelectedOption(null);
      }
    }
  }, [currentQuestion, currentAttempt]);
  
  const handleOptionSelect = (optionId: string) => {
    setSelectedOption(optionId);
  };
  
  const handleNextQuestion = async () => {
    if (!currentQuestion || !selectedOption || !currentAttempt) return;
    
    setIsSubmitting(true);
    
    try {
      // Submit the answer
      await submitAnswer(currentQuestion.id, selectedOption);
      
      // Move to next question or complete quiz
      if (currentQuestionIndex < questions.length - 1) {
        setCurrentQuestionIndex(currentQuestionIndex + 1);
        setSelectedOption(null);
      } else {
        await handleCompleteQuiz();
      }
    } catch (error) {
      console.error('Error submitting answer:', error);
    } finally {
      setIsSubmitting(false);
    }
  };
  
  const handlePrevQuestion = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(currentQuestionIndex - 1);
    }
  };
  
  const handleCompleteQuiz = async () => {
    if (!currentAttempt) return;
    
    try {
      await completeQuiz();
      navigate(`/results/${currentAttempt.id}`);
    } catch (error) {
      console.error('Error completing quiz:', error);
    }
  };
  
  // Loading state
  if (quizLoading || attemptLoading || !currentQuiz || !currentAttempt) {
    return (
      <div className="min-h-[calc(100vh-64px)] flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="w-16 h-16 border-t-4 border-b-4 border-primary-600 rounded-full animate-spin mx-auto mb-4"></div>
          <h2 className="text-xl font-semibold text-gray-700 mb-2">Loading Quiz</h2>
          <p className="text-gray-500">Please wait while we prepare your quiz...</p>
        </div>
      </div>
    );
  }
  
  if (!currentQuestion) {
    return (
      <div className="min-h-[calc(100vh-64px)] flex items-center justify-center bg-gray-50">
        <div className="text-center max-w-md mx-auto p-6 bg-white rounded-lg shadow-md">
          <HelpCircle className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <h2 className="text-xl font-semibold text-gray-700 mb-2">No Questions Available</h2>
          <p className="text-gray-500 mb-4">This quiz doesn't have any questions yet.</p>
          <button
            onClick={() => navigate('/quizzes')}
            className="btn btn-primary"
          >
            Back to Quizzes
          </button>
        </div>
      </div>
    );
  }
  
  return (
    <div className="min-h-[calc(100vh-64px)] bg-gray-50 py-8">
      <div className="container-tight max-w-4xl animate-fadeIn">
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="bg-primary-600 text-white p-6">
            <h1 className="text-xl md:text-2xl font-bold">{currentQuiz.title}</h1>
            
            <div className="flex flex-wrap items-center gap-4 mt-4">
              <div className="flex items-center">
                <Clock className="w-5 h-5 mr-2" />
                <span>
                  Time Left: <strong>{timeLeft !== null ? formatTime(timeLeft) : '--:--'}</strong>
                </span>
              </div>
              
              <div>
                Question {currentQuestionIndex + 1} of {questions.length}
              </div>
              
              {timeLeft !== null && timeLeft < 60 && (
                <div className="bg-red-100 text-red-800 px-3 py-1 rounded-full flex items-center text-sm animate-pulse">
                  <AlertTriangle className="w-4 h-4 mr-1" />
                  <span>Time running out!</span>
                </div>
              )}
            </div>
          </div>
          
          <div className="p-6">
            <div className="mb-8">
              <div className="text-lg font-medium mb-6">
                {currentQuestion.text}
              </div>
              
              <div className="space-y-3">
                {currentQuestion.options.map((option) => (
                  <div key={option.id}>
                    <label
                      className={`flex items-center p-4 rounded-md border-2 cursor-pointer transition-all ${
                        selectedOption === option.id
                          ? 'border-primary-600 bg-primary-50'
                          : 'border-gray-200 hover:border-primary-300 hover:bg-gray-50'
                      }`}
                    >
                      <input
                        type="radio"
                        name="answer"
                        className="h-5 w-5 text-primary-600 focus:ring-primary-500 border-gray-300"
                        checked={selectedOption === option.id}
                        onChange={() => handleOptionSelect(option.id)}
                      />
                      <span className="ml-3">{option.text}</span>
                    </label>
                  </div>
                ))}
              </div>
            </div>
            
            <div className="flex justify-between">
              <button
                onClick={handlePrevQuestion}
                disabled={currentQuestionIndex === 0 || isSubmitting}
                className={`btn ${
                  currentQuestionIndex === 0
                    ? 'bg-gray-200 text-gray-500 cursor-not-allowed'
                    : 'btn-outline'
                }`}
              >
                Previous
              </button>
              
              <button
                onClick={handleNextQuestion}
                disabled={!selectedOption || isSubmitting}
                className="btn btn-primary"
              >
                {isSubmitting ? (
                  <span className="flex items-center">
                    <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></span>
                    Submitting...
                  </span>
                ) : currentQuestionIndex < questions.length - 1 ? (
                  'Next Question'
                ) : (
                  'Finish Quiz'
                )}
              </button>
            </div>
          </div>
          
          <div className="bg-gray-50 p-4 border-t">
            <div className="flex justify-between items-center">
              <div className="flex items-center text-gray-500 text-sm">
                <CheckCircle className="w-4 h-4 mr-1" />
                <span>
                  {currentAttempt.answers.length} of {questions.length} questions answered
                </span>
              </div>
              
              {currentQuestionIndex < questions.length - 1 && (
                <button
                  onClick={handleCompleteQuiz}
                  className="text-sm text-primary-600 hover:text-primary-800"
                >
                  Submit quiz early
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TakeQuiz;