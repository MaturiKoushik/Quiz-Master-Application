import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useQuizStore } from '../../store/quizStore';
import { useQuizAttemptStore } from '../../store/quizAttemptStore';
import { Award, Clock, CheckCircle, X, BarChart2, Share2 } from 'lucide-react';

const Results = () => {
  const { id } = useParams<{ id: string }>();
  const { fetchAttempt, currentAttempt, isLoading: attemptLoading } = useQuizAttemptStore();
  const { questions, fetchQuestions, isLoading: questionsLoading } = useQuizStore();
  const [isShareMenuOpen, setIsShareMenuOpen] = useState(false);
  
  useEffect(() => {
    if (id) {
      fetchAttempt(id);
    }
  }, [id, fetchAttempt]);
  
  useEffect(() => {
    if (currentAttempt) {
      fetchQuestions(currentAttempt.quizId);
    }
  }, [currentAttempt, fetchQuestions]);
  
  if (attemptLoading || questionsLoading || !currentAttempt) {
    return (
      <div className="min-h-[calc(100vh-64px)] flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="w-16 h-16 border-t-4 border-b-4 border-primary-600 rounded-full animate-spin mx-auto mb-4"></div>
          <h2 className="text-xl font-semibold text-gray-700 mb-2">Loading Results</h2>
          <p className="text-gray-500">Please wait while we prepare your results...</p>
        </div>
      </div>
    );
  }
  
  // Calculate results
  const correctAnswers = currentAttempt.answers.filter(a => a.isCorrect).length;
  const totalQuestions = questions.length;
  const scorePercent = Math.round((currentAttempt.score / currentAttempt.maxScore) * 100);
  const quizStartTime = new Date(currentAttempt.startedAt);
  const quizEndTime = currentAttempt.completedAt ? new Date(currentAttempt.completedAt) : new Date();
  const duration = Math.floor((quizEndTime.getTime() - quizStartTime.getTime()) / (1000 * 60)); // in minutes
  
  const handleShareClick = () => {
    setIsShareMenuOpen(!isShareMenuOpen);
  };
  
  return (
    <div className="min-h-[calc(100vh-64px)] bg-gray-50 py-8">
      <div className="container-tight max-w-4xl animate-fadeIn">
        <div className="bg-white rounded-lg shadow-md overflow-hidden mb-8">
          <div className="bg-primary-600 text-white p-6 text-center">
            <h1 className="text-xl md:text-2xl font-bold mb-4">Quiz Results</h1>
            
            <div className="flex justify-center">
              <div className="relative w-32 h-32">
                <svg className="w-full h-full" viewBox="0 0 100 100">
                  <circle
                    className="text-primary-800 stroke-current"
                    strokeWidth="8"
                    fill="transparent"
                    r="42"
                    cx="50"
                    cy="50"
                  />
                  <circle
                    className="text-accent-400 stroke-current"
                    strokeWidth="8"
                    strokeLinecap="round"
                    fill="transparent"
                    r="42"
                    cx="50"
                    cy="50"
                    strokeDasharray="264"
                    strokeDashoffset={264 - (264 * scorePercent) / 100}
                    transform="rotate(-90 50 50)"
                  />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-white text-2xl font-bold">{scorePercent}%</div>
                </div>
              </div>
            </div>
            
            <div className="mt-4 flex flex-wrap justify-center gap-4">
              <div className="flex items-center">
                <Award className="mr-2 h-5 w-5" />
                <span>
                  Score: {currentAttempt.score}/{currentAttempt.maxScore}
                </span>
              </div>
              <div className="flex items-center">
                <CheckCircle className="mr-2 h-5 w-5" />
                <span>
                  {correctAnswers} of {totalQuestions} Correct
                </span>
              </div>
              <div className="flex items-center">
                <Clock className="mr-2 h-5 w-5" />
                <span>
                  Time: {duration} minutes
                </span>
              </div>
            </div>
          </div>
          
          <div className="p-6">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
              <h2 className="text-xl font-bold">Question Breakdown</h2>
              
              <div className="flex gap-2">
                <Link to={`/quiz/${currentAttempt.quizId}`} className="btn btn-primary">
                  Retake Quiz
                </Link>
                
                <div className="relative">
                  <button
                    onClick={handleShareClick}
                    className="btn btn-outline flex items-center gap-1"
                  >
                    <Share2 className="h-4 w-4" />
                    <span>Share</span>
                  </button>
                  
                  {isShareMenuOpen && (
                    <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg z-10 animate-fadeIn">
                      <div className="py-1">
                        <button className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-100">
                          Copy Results Link
                        </button>
                        <button className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-100">
                          Share on Twitter
                        </button>
                        <button className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-100">
                          Share on Facebook
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
            
            <div className="space-y-6">
              {questions.map((question, index) => {
                const userAnswer = currentAttempt.answers.find(a => a.questionId === question.id);
                const isCorrect = userAnswer?.isCorrect;
                const selectedOption = question.options.find(o => o.id === userAnswer?.selectedOptionId);
                const correctOption = question.options.find(o => o.id === question.correctOptionId);
                
                return (
                  <div 
                    key={question.id} 
                    className={`p-4 rounded-lg border ${
                      isCorrect ? 'border-green-200 bg-green-50' : 'border-red-200 bg-red-50'
                    }`}
                  >
                    <div className="flex justify-between items-start mb-2">
                      <h3 className="font-medium">
                        Question {index + 1}: {question.text}
                      </h3>
                      <div className={`flex items-center ${
                        isCorrect ? 'text-green-600' : 'text-red-600'
                      }`}>
                        {isCorrect ? (
                          <CheckCircle className="h-5 w-5 mr-1" />
                        ) : (
                          <X className="h-5 w-5 mr-1" />
                        )}
                        <span className="font-medium">
                          {isCorrect ? 'Correct' : 'Incorrect'}
                        </span>
                      </div>
                    </div>
                    
                    <div className="mb-4">
                      <div className="text-sm text-gray-600 mb-2">Your answer:</div>
                      <div className={`p-3 rounded-md ${
                        isCorrect ? 'bg-green-100 border border-green-200' : 'bg-red-100 border border-red-200'
                      }`}>
                        {selectedOption ? selectedOption.text : 'No answer provided'}
                      </div>
                    </div>
                    
                    {!isCorrect && (
                      <div>
                        <div className="text-sm text-gray-600 mb-2">Correct answer:</div>
                        <div className="p-3 rounded-md bg-green-100 border border-green-200">
                          {correctOption ? correctOption.text : 'N/A'}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-6 text-center">
          <div className="mb-4">
            <BarChart2 className="h-12 w-12 text-primary-500 mx-auto mb-2" />
            <h2 className="text-xl font-bold">How did you do?</h2>
          </div>
          
          <p className="text-lg mb-6">
            {scorePercent >= 80
              ? 'Excellent! You have a strong understanding of this subject.'
              : scorePercent >= 60
              ? 'Good job! You have a solid grasp of this material.'
              : scorePercent >= 40
              ? 'Not bad. With a bit more study, you can improve your score.'
              : 'You might need to review this material more thoroughly.'}
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/quizzes" className="btn btn-primary">
              Take Another Quiz
            </Link>
            <Link to="/dashboard" className="btn btn-outline">
              Back to Dashboard
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Results;