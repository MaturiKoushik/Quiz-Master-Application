import { useEffect, useState } from 'react';
import { useAuthStore } from '../../store/authStore';
import { useQuizAttemptStore } from '../../store/quizAttemptStore';
import { User, Mail, Calendar, Award, Clock, Edit, Save, X } from 'lucide-react';

const Profile = () => {
  const { user } = useAuthStore();
  const { attempts, fetchAttempts, isLoading } = useQuizAttemptStore();
  
  const [isEditing, setIsEditing] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  
  useEffect(() => {
    if (user) {
      fetchAttempts(user.id);
      setName(user.name);
      setEmail(user.email);
    }
  }, [user, fetchAttempts]);
  
  // Calculate stats
  const totalAttempts = attempts.length;
  const completedAttempts = attempts.filter(a => a.completedAt).length;
  const averageScore = completedAttempts > 0
    ? attempts.reduce((sum, a) => sum + (a.score / a.maxScore) * 100, 0) / completedAttempts
    : 0;
  
  const handleEditToggle = () => {
    if (isEditing) {
      // Reset form if canceling edit
      setName(user?.name || '');
      setEmail(user?.email || '');
    }
    setIsEditing(!isEditing);
  };
  
  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real app, you would call an API to update the user profile
    setIsEditing(false);
    
    // For demo purposes, we'll just log the changes
    console.log('Profile update:', { name, email });
    
    // Show success message (would be handled by a proper notification system)
    alert('Profile updated successfully!');
  };
  
  if (!user) {
    return (
      <div className="min-h-[calc(100vh-64px)] flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="w-16 h-16 border-t-4 border-b-4 border-primary-600 rounded-full animate-spin mx-auto mb-4"></div>
          <h2 className="text-xl font-semibold text-gray-700 mb-2">Loading Profile</h2>
        </div>
      </div>
    );
  }
  
  return (
    <div className="container-tight py-8 animate-fadeIn">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="md:col-span-1">
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="bg-primary-600 p-6 text-white text-center">
              <div className="w-24 h-24 rounded-full bg-white flex items-center justify-center mx-auto mb-4">
                <User className="w-12 h-12 text-primary-600" />
              </div>
              <h2 className="text-xl font-bold">{user.name}</h2>
              <p className="text-primary-100 capitalize">{user.role}</p>
            </div>
            
            <div className="p-6">
              {isEditing ? (
                <form onSubmit={handleSaveProfile}>
                  <div className="space-y-4">
                    <div>
                      <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                        Full Name
                      </label>
                      <input
                        type="text"
                        id="name"
                        className="input-field"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        required
                      />
                    </div>
                    
                    <div>
                      <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                        Email Address
                      </label>
                      <input
                        type="email"
                        id="email"
                        className="input-field"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                      />
                    </div>
                    
                    <div className="flex space-x-2">
                      <button
                        type="submit"
                        className="btn btn-primary flex-1 flex items-center justify-center"
                      >
                        <Save className="w-4 h-4 mr-2" />
                        Save
                      </button>
                      <button
                        type="button"
                        onClick={handleEditToggle}
                        className="btn btn-outline flex items-center justify-center"
                      >
                        <X className="w-4 h-4 mr-2" />
                        Cancel
                      </button>
                    </div>
                  </div>
                </form>
              ) : (
                <div className="space-y-4">
                  <div>
                    <div className="flex items-center text-gray-500 mb-1">
                      <Mail className="w-4 h-4 mr-2" />
                      <span className="text-sm">Email</span>
                    </div>
                    <p>{user.email}</p>
                  </div>
                  
                  <div>
                    <div className="flex items-center text-gray-500 mb-1">
                      <Calendar className="w-4 h-4 mr-2" />
                      <span className="text-sm">Joined</span>
                    </div>
                    <p>{new Date(user.createdAt).toLocaleDateString()}</p>
                  </div>
                  
                  <button
                    onClick={handleEditToggle}
                    className="btn btn-outline w-full flex items-center justify-center"
                  >
                    <Edit className="w-4 h-4 mr-2" />
                    Edit Profile
                  </button>
                </div>
              )}
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow-md overflow-hidden mt-6">
            <div className="p-6">
              <h3 className="text-lg font-semibold mb-4">Statistics</h3>
              
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-gray-600">Total Attempts</span>
                    <span className="font-medium">{totalAttempts}</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className="bg-primary-600 h-2 rounded-full"
                      style={{ width: `${(totalAttempts / Math.max(totalAttempts, 10)) * 100}%` }}
                    ></div>
                  </div>
                </div>
                
                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-gray-600">Completed Quizzes</span>
                    <span className="font-medium">{completedAttempts}</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className="bg-secondary-600 h-2 rounded-full"
                      style={{ width: `${(completedAttempts / Math.max(totalAttempts, 1)) * 100}%` }}
                    ></div>
                  </div>
                </div>
                
                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-gray-600">Average Score</span>
                    <span className="font-medium">{averageScore.toFixed(1)}%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className={`h-2 rounded-full ${
                        averageScore >= 70
                          ? 'bg-green-500'
                          : averageScore >= 40
                          ? 'bg-yellow-500'
                          : 'bg-red-500'
                      }`}
                      style={{ width: `${averageScore}%` }}
                    ></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div className="md:col-span-2">
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="p-6 border-b">
              <h3 className="text-lg font-semibold">Quiz History</h3>
            </div>
            
            {isLoading ? (
              <div className="p-6 animate-pulse space-y-4">
                {[...Array(3)].map((_, index) => (
                  <div key={index} className="border rounded-lg p-4">
                    <div className="h-4 bg-gray-200 rounded w-1/2 mb-4"></div>
                    <div className="h-4 bg-gray-200 rounded w-1/4 mb-2"></div>
                    <div className="h-4 bg-gray-200 rounded w-1/3"></div>
                  </div>
                ))}
              </div>
            ) : attempts.length > 0 ? (
              <div className="divide-y">
                {attempts
                  .sort((a, b) => new Date(b.startedAt).getTime() - new Date(a.startedAt).getTime())
                  .map((attempt) => {
                    const scorePercent = (attempt.score / attempt.maxScore) * 100;
                    
                    return (
                      <div key={attempt.id} className="p-6 hover:bg-gray-50 transition-colors">
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-4">
                          <div>
                            <h4 className="font-medium text-lg">Quiz ID: {attempt.quizId}</h4>
                            <div className="flex items-center text-sm text-gray-500 mt-1">
                              <Calendar className="w-4 h-4 mr-1" />
                              <span>{new Date(attempt.startedAt).toLocaleDateString()}</span>
                              
                              {attempt.completedAt && (
                                <>
                                  <span className="mx-2">•</span>
                                  <Clock className="w-4 h-4 mr-1" />
                                  <span>
                                    {Math.round(
                                      (new Date(attempt.completedAt).getTime() -
                                        new Date(attempt.startedAt).getTime()) /
                                        (1000 * 60)
                                    )}{' '}
                                    minutes
                                  </span>
                                </>
                              )}
                            </div>
                          </div>
                          
                          {attempt.completedAt ? (
                            <div className="flex items-center mt-2 sm:mt-0">
                              <Award className="w-5 h-5 text-accent-500 mr-2" />
                              <span className="font-bold">{scorePercent.toFixed(0)}%</span>
                            </div>
                          ) : (
                            <div className="px-3 py-1 bg-yellow-100 text-yellow-800 rounded-full text-sm mt-2 sm:mt-0">
                              Incomplete
                            </div>
                          )}
                        </div>
                        
                        {attempt.completedAt && (
                          <div className="mt-2">
                            <div className="w-full bg-gray-200 rounded-full h-2">
                              <div
                                className={`h-2 rounded-full ${
                                  scorePercent >= 70
                                    ? 'bg-green-500'
                                    : scorePercent >= 40
                                    ? 'bg-yellow-500'
                                    : 'bg-red-500'
                                }`}
                                style={{ width: `${scorePercent}%` }}
                              ></div>
                            </div>
                            <div className="flex justify-between text-xs text-gray-500 mt-1">
                              <span>Score: {attempt.score}/{attempt.maxScore}</span>
                              <span>
                                {scorePercent >= 70
                                  ? 'Excellent'
                                  : scorePercent >= 40
                                  ? 'Good'
                                  : 'Needs Improvement'}
                              </span>
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })}
              </div>
            ) : (
              <div className="p-12 text-center">
                <Award className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-xl font-medium text-gray-900 mb-2">No quiz attempts yet</h3>
                <p className="text-gray-500 max-w-md mx-auto mb-6">
                  You haven't taken any quizzes yet. Start your learning journey by taking a quiz!
                </p>
                <a href="/quizzes" className="btn btn-primary">
                  Browse Quizzes
                </a>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;