import { Link } from 'react-router-dom';
import { BookOpen, Award, Users, Clock } from 'lucide-react';
import { useAuthStore } from '../store/authStore';

const Home = () => {
  const { isAuthenticated } = useAuthStore();
  
  return (
    <div>
      {/* Hero Section */}
      <section className="bg-gradient-to-b from-primary-700 to-primary-900 text-white py-20">
        <div className="container-tight">
          <div className="flex flex-col md:flex-row items-center">
            <div className="md:w-1/2 mb-10 md:mb-0">
              <h1 className="text-4xl md:text-5xl font-bold mb-4 leading-tight animate-fadeIn">
                Test Your Knowledge with Interactive Quizzes
              </h1>
              <p className="text-xl mb-8 text-primary-100 max-w-lg animate-slideUp opacity-0" style={{ animationDelay: '200ms', animationFillMode: 'forwards' }}>
                Create, share, and take quizzes on any topic. Perfect for learning, teaching, or just having fun.
              </p>
              <div className="space-x-4 animate-slideUp opacity-0" style={{ animationDelay: '400ms', animationFillMode: 'forwards' }}>
                {isAuthenticated ? (
                  <Link to="/quizzes" className="btn btn-accent">
                    Browse Quizzes
                  </Link>
                ) : (
                  <>
                    <Link to="/register" className="btn btn-accent">
                      Get Started
                    </Link>
                    <Link to="/login" className="btn btn-outline bg-transparent text-white border-white hover:bg-white hover:text-primary-700">
                      Log In
                    </Link>
                  </>
                )}
              </div>
            </div>
            <div className="md:w-1/2 flex justify-center">
              <div className="relative w-80 h-80 bg-white rounded-full overflow-hidden shadow-xl animate-fadeIn opacity-0" style={{ animationDelay: '300ms', animationFillMode: 'forwards' }}>
                <div className="absolute inset-0 bg-gradient-to-br from-primary-100 to-primary-300 opacity-90"></div>
                <div className="absolute inset-0 flex items-center justify-center">
                  <BookOpen className="w-32 h-32 text-primary-700" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* Features Section */}
      <section className="py-16 bg-gray-50">
        <div className="container-tight">
          <h2 className="text-3xl font-bold text-center mb-12">Why Choose QuizMaster?</h2>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
              <div className="w-12 h-12 bg-primary-100 rounded-full flex items-center justify-center mb-4">
                <BookOpen className="w-6 h-6 text-primary-700" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Diverse Quiz Library</h3>
              <p className="text-gray-600">
                Access quizzes across various subjects and difficulty levels created by our community.
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
              <div className="w-12 h-12 bg-secondary-100 rounded-full flex items-center justify-center mb-4">
                <Users className="w-6 h-6 text-secondary-700" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Easy Quiz Creation</h3>
              <p className="text-gray-600">
                Create your own quizzes with our intuitive interface and share them with others.
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
              <div className="w-12 h-12 bg-accent-100 rounded-full flex items-center justify-center mb-4">
                <Award className="w-6 h-6 text-accent-700" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Detailed Results</h3>
              <p className="text-gray-600">
                Get immediate feedback with detailed analysis of your quiz performance.
              </p>
            </div>
          </div>
        </div>
      </section>
      
      {/* CTA Section */}
      <section className="py-16 bg-secondary-700 text-white">
        <div className="container-tight text-center">
          <h2 className="text-3xl font-bold mb-4">Ready to Test Your Knowledge?</h2>
          <p className="text-xl mb-8 max-w-xl mx-auto">
            Join thousands of users who are already creating and taking quizzes on QuizMaster.
          </p>
          <div className="space-x-4">
            {isAuthenticated ? (
              <Link to="/quizzes" className="btn btn-accent">
                Browse Quizzes
              </Link>
            ) : (
              <Link to="/register" className="btn btn-accent">
                Create Your Free Account
              </Link>
            )}
          </div>
        </div>
      </section>
      
      {/* Stats Section */}
      <section className="py-16">
        <div className="container-tight">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-4xl font-bold text-primary-600 mb-2">500+</div>
              <div className="text-gray-600">Quizzes Available</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-primary-600 mb-2">10k+</div>
              <div className="text-gray-600">Users</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-primary-600 mb-2">50k+</div>
              <div className="text-gray-600">Quizzes Taken</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-primary-600 mb-2">100+</div>
              <div className="text-gray-600">Topics</div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;