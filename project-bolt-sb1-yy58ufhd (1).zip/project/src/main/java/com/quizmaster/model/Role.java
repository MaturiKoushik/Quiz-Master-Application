package com.quizmaster.model;

public enum Role {
    USER,
    ADMIN
}