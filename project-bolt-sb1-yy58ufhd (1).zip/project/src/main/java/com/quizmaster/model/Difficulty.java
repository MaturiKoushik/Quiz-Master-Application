package com.quizmaster.model;

public enum Difficulty {
    EASY,
    MEDIUM,
    HARD
}