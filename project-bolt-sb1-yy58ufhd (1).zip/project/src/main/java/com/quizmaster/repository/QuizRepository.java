package com.quizmaster.repository;

import com.quizmaster.model.Quiz;
import com.quizmaster.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface QuizRepository extends JpaRepository<Quiz, Long> {
    List<Quiz> findByCreatedBy(User user);
    List<Quiz> findByIsPublishedTrue();
}