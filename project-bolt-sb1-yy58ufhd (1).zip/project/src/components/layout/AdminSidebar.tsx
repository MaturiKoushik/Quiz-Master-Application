import { Link, useLocation } from 'react-router-dom';
import { LayoutDashboard, BookOpen, PlusCircle, Users, Settings, ArrowLeft } from 'lucide-react';

const AdminSidebar = () => {
  const location = useLocation();
  
  const menuItems = [
    {
      path: '/admin/dashboard',
      name: 'Dashboard',
      icon: <LayoutDashboard className="w-5 h-5" />
    },
    {
      path: '/admin/quizzes',
      name: 'Quizzes',
      icon: <BookOpen className="w-5 h-5" />
    },
    {
      path: '/admin/quizzes/create',
      name: 'Create Quiz',
      icon: <PlusCircle className="w-5 h-5" />
    }
  ];
  
  return (
    <div className="bg-gray-800 text-white w-full md:w-64 py-6 px-4 md:min-h-screen">
      <div className="flex flex-col h-full">
        <div className="mb-8">
          <Link to="/admin/dashboard" className="flex items-center space-x-2">
            <BookOpen className="w-6 h-6" />
            <span className="text-lg font-bold">Admin Panel</span>
          </Link>
        </div>
        
        <nav className="flex-grow">
          <ul className="space-y-2">
            {menuItems.map((item) => (
              <li key={item.path}>
                <Link
                  to={item.path}
                  className={`flex items-center space-x-3 px-4 py-3 rounded-md transition-colors ${
                    location.pathname === item.path
                      ? 'bg-primary-700 text-white'
                      : 'text-gray-300 hover:bg-gray-700'
                  }`}
                >
                  {item.icon}
                  <span>{item.name}</span>
                </Link>
              </li>
            ))}
          </ul>
        </nav>
        
        <div className="mt-auto pt-6 border-t border-gray-700">
          <Link
            to="/"
            className="flex items-center space-x-3 px-4 py-3 text-gray-300 hover:bg-gray-700 rounded-md transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            <span>Back to Site</span>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default AdminSidebar;