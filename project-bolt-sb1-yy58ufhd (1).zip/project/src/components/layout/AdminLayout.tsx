import { Outlet } from 'react-router-dom';
import AdminSidebar from './AdminSidebar';

const AdminLayout = () => {
  return (
    <div className="flex flex-col md:flex-row min-h-screen bg-gray-100">
      <AdminSidebar />
      
      <div className="flex-1 overflow-x-hidden overflow-y-auto">
        <div className="container-tight py-6">
          <Outlet />
        </div>
      </div>
    </div>
  );
};

export default AdminLayout;